package com.georgeflug.budget.transactions

import org.junit.Test

class TransactionListFragmentTest {

    @Test
    fun test() {
    }
}