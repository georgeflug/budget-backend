package com.georgeflug.budget.model

class BackendStatus(
        val status: String
)
