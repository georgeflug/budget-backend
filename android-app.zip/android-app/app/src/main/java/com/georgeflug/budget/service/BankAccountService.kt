package com.georgeflug.budget.service

class BankAccountService {
    companion object {

    }
}
