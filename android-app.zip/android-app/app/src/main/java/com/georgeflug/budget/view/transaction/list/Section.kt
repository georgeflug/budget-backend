package com.georgeflug.budget.view.transaction.list

data class Section(val name: String)
