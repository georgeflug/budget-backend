package com.georgeflug.budget.model

class FeatureIdea(
        val date: String,
        val description: String
)
