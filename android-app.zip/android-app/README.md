I have updated the code to use the new api but I have not tried it out at all.
I should run the server locally and test out the app. It's surely broken.

## Todo
1. Keep track of account balances so that missing transactions can be tracked.
1. Idea: "Events" can group transactions together.
    * Group all transactions from a trip together.
    * Group all transactions from a project together.
    * Use hashtag??
1. Idea: Auto-suggest a budget. Highlight a budget so it's easier to click.
1. Idea: Show number of uncategorized transactions
1. Separate budgets into Common and Other
1. Separate Work Expenses into Richie/Stef
   1. Consider "drill-down" style budgets

Fix:
1. Need way to save/remove description on categories that do not normally need a description.
1. Touch feedback on budget icons
